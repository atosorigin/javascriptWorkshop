﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace JavaScript.Workshop.Areas.KnockoutJS.Controllers
{
    public class SimpleBindingsController : Controller
    {
        //
        // GET: /KnockoutJS/SimpleBindings/

        public ActionResult Index()
        {
            return View();
        }

    }
}
