﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace JavaScript.Workshop.Areas.AdvancedJavascript.Controllers
{
    public class ObjectsController : Controller
    {
        //
        // GET: /AdvancedJavascript/Objects/

        public ActionResult Index()
        {
            return View();
        }

    }
}
