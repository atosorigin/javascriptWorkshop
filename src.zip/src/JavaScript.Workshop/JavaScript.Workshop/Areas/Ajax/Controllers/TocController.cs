﻿using System.Web.Mvc;

namespace JavaScript.Workshop.Areas.Ajax.Controllers
{
    public class TocController : Controller
    {
        //
        // GET: /AdvancedJavascript/Toc/

        public ActionResult Index()
        {
            return View();
        }

    }
}
